#include <stdio.h>
#include <math.h>

void main()
{
	int x=7;
	int y=x/3;
	int z=x/y;
	printf("%d\n", z);
}
